from django.shortcuts import render

# Create your views here.

header_menu_links = [
    {'url': 'blog:index', 'name': 'Лента записей'},
    {'url': 'pages:about', 'name': 'О проекте'},
    {'url': 'pages:rules', 'name': 'Наши правила'},
]


def about(request):
    """Отображает страницу о проекте."""
    title = 'О проекте'
    template_name = 'pages/about.html'
    context = {
        'title': title,
        'links': header_menu_links,
    }
    return render(request, template_name, context)


def rules(request):
    """Отображает страницу с правилами."""
    title = 'Наши правила'
    template_name = 'pages/rules.html'
    context = {
        'title': title,
        'links': header_menu_links,
    }
    return render(request, template_name, context)
