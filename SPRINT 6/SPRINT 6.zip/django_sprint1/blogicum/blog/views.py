from django.shortcuts import render

posts = [
    {
        'id': 0,
        'location': 'Остров отчаянья',
        'date': '30 сентября 1659 года',
        'category': 'travel',
        'text': '''Наш корабль, застигнутый в открытом море
                страшным штормом, потерпел крушение.
                Весь экипаж, кроме меня, утонул; я же,
                несчастный Робинзон Крузо, был выброшен
                полумёртвым на берег этого проклятого острова,
                который назвал островом Отчаяния.''',
    },
    {
        'id': 1,
        'location': 'Остров отчаянья',
        'date': '1 октября 1659 года',
        'category': 'not-my-day',
        'text': '''Проснувшись поутру, я увидел, что наш корабль сняло
                с мели приливом и пригнало гораздо ближе к берегу.
                Это подало мне надежду, что, когда ветер стихнет,
                мне удастся добраться до корабля и запастись едой и
                другими необходимыми вещами. Я немного приободрился,
                хотя печаль о погибших товарищах не покидала меня.
                Мне всё думалось, что, останься мы на корабле, мы
                непременно спаслись бы. Теперь из его обломков мы могли бы
                построить баркас, на котором и выбрались бы из этого
                гиблого места.''',
    },
    {
        'id': 2,
        'location': 'Остров отчаянья',
        'date': '25 октября 1659 года',
        'category': 'not-my-day',
        'text': '''Всю ночь и весь день шёл дождь и дул сильный
                порывистый ветер. 25 октября.  Корабль за ночь разбило
                в щепки; на том месте, где он стоял, торчат какие-то
                жалкие обломки,  да и те видны только во время отлива.
                Весь этот день я хлопотал  около вещей: укрывал и
                укутывал их, чтобы не испортились от дождя.''',
    },
]

header_menu_links = [
    {'url': 'blog:index', 'name': 'Лента записей'},
    {'url': 'pages:about', 'name': 'О проекте'},
    {'url': 'pages:rules', 'name': 'Наши правила'},
]


def index(request):
    """Отображает главную страницу блога с лентой записей."""
    template_name = 'blog/index.html'
    title = 'Лента записей'
    context = {
        'title': title,
        'posts': posts,
        'links': header_menu_links,
    }
    return render(request, template_name, context)


def post_detail(request, id):
    """Отображает страницу конкретного поста."""
    template_name = 'blog/detail.html'
    post = posts[id]
    title = f'{post["location"]}. {post["date"]}'
    context = {
        'id': id,
        'post': post,
        'title': title,
        'links': header_menu_links,
    }
    return render(request, template_name, context)


def category_posts(request, category_slug):
    """Отображает страницы публикаций в выбранной категории."""
    template_name = 'blog/category.html'
    title = f'Публикации в категории {category_slug}'
    context = {
        'title': title,
        'category': category_slug,
        'links': header_menu_links,
    }

    return render(request, template_name, context)
